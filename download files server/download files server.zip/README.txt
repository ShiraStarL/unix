Download file server

run this files at 2 different cmd at the same time:
- localserver.c 
- localclient.c

- For the project to work you have to open 2 folders:
1. Where the "client.c" located, open a folder and name it "clientFiles".
2. Where the "server.c" located, open a folder and name it "files".

You can choose between 2 actions:
1. get-file-info fileName.txt
2. download-file fileName.txt

If choose the second action you will see the file you downloaded at "clientFiles" folder.